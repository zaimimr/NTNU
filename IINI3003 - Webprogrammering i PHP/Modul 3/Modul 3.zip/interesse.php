<b>Interesse svar:</b>
<br>
<?php
  echo "$_GET[name] er interessert i $_GET[list]";
?>
