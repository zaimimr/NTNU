<?php
include "luker.inc.php"; //har matrise med 24 tall og tekster
echo "<table border='1' align='center' width='420'>\n";
for ($rad=1;$rad<=4; $rad++){
	echo "<tr>\n";
	for ($kol=1;$kol<=6; $kol++){
		$neste = key($lukene); //henter neste tall 
		next($lukene); //�ker den interne pekeren i matrisen
		echo "\t<td height='70' 
					width='70' 
					valign='center' 
					align='middle'>";
		//$dagens_dato_som_dag = date("d");
		$dagens_dato_som_dag = 14;
		if ($neste <= $dagens_dato_som_dag ) {
			echo "<a href='julekalender_vis.php?luke=$neste'><font size=6>$neste</font></a>";
		}
		else {
			echo "<font size=6>$neste</font>";
		}
		echo "</td>\n";
	}//kolonner
	echo "</tr>\n\n";
}//rader

echo "</table>";
?>
