<?php
//har her matrisen med riktige tekster. 
//Merk n�kkelstart p� 1.
$lukene = array(
			0 => "Her er en feilmelding", 
			1 => "Her er teksten til nr 1", 
				 "Her er teksten til nr 2", 
				 "Her er teksten til nr 3", 
				 "Her er teksten til nr 4", 
		// alle andre kuttet bort her. De skal normalt v�re med
				 "Her er teksten til nr 5", 
				 "Her er teksten til nr 6", 
				 "Her er teksten til nr 7", 
				 "Her er teksten til nr 8", 
				 "Her er teksten til nr 9", 
				 "Her er teksten til nr 10", 
				 "Her er teksten til nr 11", 
				 "Her er teksten til nr 12", 
				 "Her er teksten til nr 13", 
				 "Her er teksten til nr 14", 
				 "Her er teksten til nr 15", 
				 "Her er teksten til nr 16", 
				 "Her er teksten til nr 17", 
				 "Her er teksten til nr 18", 
				 "Her er teksten til nr 19", 
				 "Her er teksten til nr 20", 
				 "Her er teksten til nr 21", 
				 "Her er teksten til nr 22", 
				 "Her er teksten til nr 23", 
				 "Her er teksten til nr 24"
			);  

?>
