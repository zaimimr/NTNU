<?php
include "luker.inc.php"; //har matrise med 24 tall og tekster
//$dagens_dato_som_dag = date("d");
$dagens_dato_som_dag = 14;
if ($_GET['luke'] <= $dagens_dato_som_dag ) {
	$lukenummer = $_GET['luke'];
}
else {
	$lukenummer = 0; //feilmelding
}
echo $lukene[$lukenummer];
?>
