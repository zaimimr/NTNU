<?php

function antallElementer($matrise){
	//egendefinert funksjon som finner antall elementer 
	//i en matrise uten � bruke innebygde funksjoner. 
	//Utnytter foreach for � f� det til
	$antall = 0; 
	foreach ($matrise as $nokkel => $verdi)
		$antall ++;
	return $antall;
}//slutt antallElementer

$byer = array("Bergen", "Oslo", "Trondheim", "Stavanger", "Troms�");
echo "Det er " . antallElementer($byer) . " elementer i matrisen";

?>