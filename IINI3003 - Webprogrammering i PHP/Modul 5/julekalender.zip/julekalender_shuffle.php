<?php  /* julekalender.php, versjon shuffle */
$hjelpematrise = range(1, 24);  //lager hjelpematrise
shuffle($hjelpematrise);

echo "<table border='1' align='center' width='420'>\n";
for ($rad=1;$rad<=4; $rad++){
	echo "<tr>\n";
	for ($kol=1;$kol<=6; $kol++){
		$neste = next($hjelpematrise); //henter neste tall og �ker den interne pekeren
		echo "\t<td height='70' 
					width='70' 
					valign='center' 
					align='middle'>";
		echo "<a href='julekalender_vis.php?luke=$neste'>
				<font size=6>$neste</font></a>";
		echo "</td>\n";
	}//kolonner
	echo "</tr>\n\n";
}//rader
echo "</table>";
?>
