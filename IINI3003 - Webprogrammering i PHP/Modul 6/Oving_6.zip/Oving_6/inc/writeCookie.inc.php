<?php
	echo "<pre>";
	print_r($_COOKIE);
	echo "</pre>";
?>

<br><a href='../Landing.php'>Til forsiden</a>
