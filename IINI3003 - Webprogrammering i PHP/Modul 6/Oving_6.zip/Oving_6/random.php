<!DOCTYPE html>
<html>
<head>
  <title>RandomPage</title>
  <link rel="stylesheet" href="css/main.css">
  <?php
    include "inc/functions.inc.php";
    include "inc/cookie.inc.php";
    include "inc/topBar.inc.php";
    include "css/css.php";
  ?>
</head>
<body align = "center">
  <div class="header">
  	<h2>Random Page</h2>
  </div>
  <div>
    <p>Dette er en random side bare for å vise at cookie fungerer på alle sidene</p>
  </div>

</body>
</html>
