<?php
	//Funksjon som lager tabell over skjema, slik at det blir formattert fint i to kolonner. Input er matrise med data. 
	/*Brukes slik: 
	  $matrise = array ( 
  		"E-mail" => "<input type='text' name='email'>", 
		"Pincode" => "<input type='text' name='spincode'>" 
		); //slutt p� matrise over felt som det skal lages tabell av
  lagTabell($matrise); //lager tabell uten ramme (border=false i andre arg)
	*/
function lagTabell($matrise, $border=false){
	
	echo "<table";
	if ($border) echo " border='1'";
	echo ">\n";//har n� lagd en tabell enten med eller uten ramme. 
	foreach ($matrise as $venstre => $hoyre) {
		echo "\t<tr><td bgcolor='lightgreen'>$venstre</td><td>$hoyre</td></tr>\n";
	}//slutt g� gjennom hele matrisen og lage tabell
	echo "</table>";
}//slutt lagTabell
	
	
$matrise = array ( 
	"E-postadressen din her" => "<input type='text' name='email'>", 
	"Skriv inn navnet ditt her" => "<input type='text' name='navn'>" ,
	"Skriv inn en st�rre tekst" => "<textarea name='mye'></textarea>" ,
	"" => "<input type='submit' name='knapp'>"
	); //slutt p� matrise over felt som det skal lages tabell av
echo "<form action='visinfo.php'>";
lagTabell($matrise); //lager tabell uten ramme (border=false i andre arg)
echo "</form>";
?>