<?php

echo "hei";  //vanlig tekst

echo "<p>";

include "test.txt"; //tekstfil med en linje med tekst

echo "<p>";

include "test_php.txt"; //tekstfil med PHP-kode i < ? php  tag   ? >

echo "<p>";

include "test.php";  //php-script med html og kode

echo "<p>";

?>