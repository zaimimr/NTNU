<?php

echo "<h1>Dette er filen test.php den " . date("d.m.Y") . "</h1>";

?>