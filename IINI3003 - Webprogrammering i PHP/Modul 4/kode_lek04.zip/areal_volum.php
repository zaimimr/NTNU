<html>
<head><title>L�sning til �ving 3</title></head>
<body>
<h1>Finn enten areal eller volum</h1>

<?php
	function beregn($tall1, $tall2, $tall3=1){
		//Setter tall3 = 1 for � beregne areal 
		//dersom volum-parameter er utelatt
		return($tall1 * $tall2 * $tall3);
	}

	echo "Side A er " . beregn(4, 6) . " cm<sup>2</sup><br>";
	echo "Side B er " . beregn(4, 3) . " cm<sup>2</sup><br>";
	echo "Side C er " . beregn(3, 6) . " cm<sup>2</sup><br>";
	echo "Volumet er " . beregn(4, 6, 3) . " cm<sup>3</sup><br>";


	function finnAreal($lengde, $bredde){
		$svar = $lengde * $bredde;
		return $svar;
	}

	echo "Arealet av flaten med sider 3 og 4 er ";
	echo finnAreal(3,4);
	echo "<p>";
	echo "Arealet av flaten med sider 3 og 6 er ";
	echo finnAreal(3,6);
	echo "<p>";
	echo "Arealet av flaten med sider 4 og 6 er ";
	echo finnAreal(4,6);

	echo "<p>";

	echo "Volumet av kuben i boka er ";
	$volum = finnAreal(3,4) * 6;
	echo "<strong>$volum</strong>";

	echo "<p>";
	
	echo "Totalsummen blir: ";
	$tot = finnAreal(3,4) * 2 + finnAreal(3,6) * 2 + finnAreal(4,6) * 2;
	echo $tot . " cm<sup>2</sup>";

	echo "<p>";
	for ($i = 1; $i<=30; $i++) {
		echo "Volumet av en likesidet kloss med sider p� $i cm er "; 
		echo beregn($i, $i, $i) . " cm<sup>3</sup><br>";
	}
	
	function rundGjenstand($radius, $kule = "nei"){
		if ($kule == "ja") 
			return M_PI * $radius * $radius * $radius; //kule
		else
			return M_PI * $radius * $radius; //sirkel
	}
	echo rundGjenstand(10); //areal av en sirkel med radius 10
	echo "<p>";
	echo rundGjenstand(10, "ja"); //areal av en sirkel med radius 10

	function rundGjenstand($rad, $rad, $rad = 1){
		return M_PI * $rad * $rad * $rad; //kule eller sirkel
	}

?>


</body>
</html>
