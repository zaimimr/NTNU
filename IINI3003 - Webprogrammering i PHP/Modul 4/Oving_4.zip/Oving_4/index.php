<?php
  include ".inc/topp.inc.php";
?>

<h1>Velkommen til Calfskin Games</h1>
<p>Et fiktivt firma for oppgave 2 <br>
Ta en titt på våre produkter <a href="bestill.php">her</a>
eller les litt <a href="om.php">om oss</a>.<br>
Det er også mulig å kontakte en av våre ansatte <a href="kontakt.php">om oss</a></p>

<?php
  footer();
  include ".inc/bunn.inc.php";
?>
