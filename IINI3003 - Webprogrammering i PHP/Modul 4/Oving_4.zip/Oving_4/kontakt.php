<?php
  include ".inc/topp.inc.php";
?>

<h1>Kontakt</h1>
<p>For å kontakte firmaet anbefaler jeg å finne oss i nærmeste telefonkatalog</p>
 

<?php
  include ".inc/bunn.inc.php";
?>
