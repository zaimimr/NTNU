<?php
  include ".inc/topp.inc.php";
?>

<h1>Bestilling</h1>
<p>Her kan du bestille våre produkter...</p>

<?php
  footer();
  include ".inc/bunn.inc.php";
?>
