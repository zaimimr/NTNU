<html>
<head>
  <title>Calvskin Games</title>
  <link rel='stylesheet' type='text/css' href='css/design.css'/>
</head>
<body>
  <?php
    include ".inc/funksjoner.inc.php";
    menyBar();
  ?>
