<?php
  include ".inc/topp.inc.php";
?>

<h1>Om oss</h1>
<p>Vi er Calfskin Games, en ubrukelig</p>

<?php
  footer();
  include ".inc/bunn.inc.php";
?>
