<html>
<head>
  <title>Min hjemmeside</title>
  <link rel='stylesheet' type='text/css' href='design.css' />
</head>
<body>

<h1>Side 2</h1> 
<p>Dette er side 2. bla bla bla</p> 

</body>
</html>