<?php
  include "topp.inc.php";
?>

<h1>Velkommen</h1> 
<p>Dette er min hjemmeside... 
Du kan bes�ke <a href="side2.php">side 2</a> 
og <a href="side3.php">side 3</a>.</p> 

<?php
  include "bunn.inc.php";
?>