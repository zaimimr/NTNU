<?php
  include "topp.inc.php";
?>


<h1>Side 2</h1> 
<p>Dette er side 2. bla bla bla</p> 



<?php
  include "bunn.inc.php";
?>