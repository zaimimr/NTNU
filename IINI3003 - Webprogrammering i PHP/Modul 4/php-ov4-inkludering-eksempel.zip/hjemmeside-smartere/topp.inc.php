<html>
<head>
  <title>Min hjemmeside</title>
  <link rel='stylesheet' type='text/css' href='design.css' />
</head>
<body>