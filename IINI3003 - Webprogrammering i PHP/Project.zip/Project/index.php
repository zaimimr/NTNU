<head>
<?php
  include "./inc/top.inc.php";
?>
</head>
<body>
  <div class='sections'>
    <div class='cards'> 
      <p>I'm gonna add just a tiny little amount of Prussian Blue. Let's put a touch more of the magic here. We'll play with clouds today. Work on one thing at a time. Don't get carried away - we have plenty of time.</p>
      <p>You have to make those little noises or it won't work. Work that paint. Follow the lay of the land. It's most important. It looks so good, I might as well not stop.</p>
      <p>That's the way I look when I get home late; black and blue. We can fix anything. These things happen automatically. All you have to do is just let them happen. Now we'll take the almighty fan brush. Each highlight must have it's own private shadow. If there's two big trees invariably sooner or later there's gonna be a little tree.</p>
      <p>I like to beat the brush. The man who does the best job is the one who is happy at his job. Isn't that fantastic that you can create an almighty tree that fast? This is an example of what you can do with just a few things, a little imagination and a happy dream in your heart. You have to make almighty decisions when you're the creator. A happy cloud.</p>
      <p>We're trying to teach you a technique here and how to use it. We spend so much of our life looking - but never seeing. Trees cover up a multitude of sins. Happy painting, God bless. Just let go - and fall like a little waterfall. And I will hypnotize that just a little bit.</p>
      <p>Isn't that fantastic? It's a good way of getting rid of all your anxieties and hostilities. Let's just drop a little Evergreen right here. Of course he's a happy little stone, cause we don't have any other kind. It's life. It's interesting. It's fun.</p>
      <p>Everything is happy if you choose to make it that way. Let's put some happy little bushes on the other side now. Let's build some happy little clouds up here. Let's do that again. We don't have anything but happy trees here.</p>
    </div>
  </div>
</body>
