<link rel="stylesheet" href="./css/style.css">
<?php
  include "function.inc.php";
  include "DataBase.inc.php";
  menuBar();
?>