package leksjon.traad;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.widget.TextView;

public class TimeActivityWithThreads extends Activity {
    private TextView timeView;
    private TextView smsView;
    private TimeThread timeThread;
    private SMSThread smsThread;
    
    private Handler handler = new Handler();
    
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);//for showing progress bar
        setContentView(R.layout.main);
        timeView = (TextView)findViewById(R.id.clock);
        smsView = (TextView)findViewById(R.id.sms);
    }
    
    @Override
    /* This method is run when starting and resuming activity */
    protected void onResume() {
    	super.onResume();
		smsThread = new SMSThread(this);
		smsThread.start();
    	
		timeThread = new TimeThread(this);
		timeThread.execute(); 
    };
    
    @Override
    /* This method is run when stopping or pausing the activity. 
     * We must stop threads or they will continue to run! */
    protected void onPause() {
    	super.onPause();    	
    	timeThread.cancel(true);//stop thread
    	smsThread.interrupt();//stop thread via interrupt (must handle this in thread).
    };
    
    /* This method will be called from this thread 
     * (even though this is from within the timeThread object).
     * We can access the timeView component directly. */
    public void setTimeView(final String text){
    	timeView.setText(text);//Change UI view    	
    }
    
    /* This method will be called from another thread (smsThread).
     * Don't access the smsView component directly.
     * Must be accessed via handler!!   */
    public void setSmsView(final String text){
    	handler.post(new Thread(){
			@Override
			public void run(){
				smsView.setText(text);//Change UI view
			}
		});
    }
}
