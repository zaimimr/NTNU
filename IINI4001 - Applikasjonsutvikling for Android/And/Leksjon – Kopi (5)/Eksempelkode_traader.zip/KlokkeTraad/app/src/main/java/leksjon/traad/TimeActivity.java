package leksjon.traad;

import java.util.Calendar;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class TimeActivity extends Activity {
    final static String TAG = "TimeActivity"; 
	/** Called when the activity is first created. */
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        TextView clockView = (TextView)findViewById(R.id.clock);
        
        Log.i(TAG,"starter...");
		
      //DON'T DO THIS IN REAL LIFE!! 
      //LET onCreate()-method finish! Create new thread instead!!
        while (true){  
			Log.i(TAG,"skal skrive ut klokka");
			Log.i(TAG,"Tiden er: " + hentTid(Calendar.getInstance()));
			sleep(1);//sov 1 sekund
			sendSMS();
		}
    }
    
    private void sendSMS(){
		Log.i(TAG,"starter å sende ny sms *************************");
		sleep(10);//sov i 10 sekunder, later som om vi sender sms
		Log.i(TAG,"ferdig å sende sms ************************* ");
	}

	private void sleep(int seconds){
		try{
			Thread.sleep(seconds*1000);
		}catch(InterruptedException e){}
	}

	//Get current time with some formatting
	private String hentTid(Calendar cal){
		
		int time 		= cal.get(Calendar.HOUR_OF_DAY);
		int minutt 		= cal.get(Calendar.MINUTE);
		int sekund 		= cal.get(Calendar.SECOND);
		
		String sTime 	= String.valueOf(time);
		String sMinutt 	= String.valueOf(minutt);
		String sSekund 	= String.valueOf(sekund);
		
		if (sTime.length() == 1) 	sTime 	= "0" + sTime;
		if (sMinutt.length() == 1)	sMinutt = "0" + sMinutt;
		if (sSekund.length() == 1) 	sSekund = "0" + sSekund;
		return sTime + ":" + sMinutt + ":" + sSekund;
	}
}