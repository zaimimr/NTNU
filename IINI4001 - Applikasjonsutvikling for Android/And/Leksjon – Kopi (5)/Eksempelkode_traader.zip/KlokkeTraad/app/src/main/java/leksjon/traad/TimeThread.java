package leksjon.traad;

import java.util.Calendar;

import android.os.AsyncTask;
import android.util.Log;

public class TimeThread extends AsyncTask<Void, String, Boolean> {
	private static final String TAG = "TimeThread";
	private TimeActivityWithThreads activity;

	public TimeThread(TimeActivityWithThreads activity) {
		this.activity = activity;
	}

	protected void onPreExecute() {
		activity.setProgressBarIndeterminateVisibility(true);// show progress
																// bar
	}

	@SuppressWarnings("unchecked")
	@Override
	/*
	 * This is where the work is done. This method is run as a seperate thread
	 * (not part of UI thread).
	 */
	protected Boolean doInBackground(Void... v) {
		boolean result = false;
		while (!this.isCancelled()) {
			String time = getTime(Calendar.getInstance());
			publishProgress(time);// publish new time to UI thread via
									// onProgressUpdate()
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// don't have to do anything in this case
			}
		}

		return result;
	}

	@Override
	/* This method is run by the UI thread updates of the UI should be done here */
	protected void onProgressUpdate(String... values) {
		activity.setTimeView(values[0]);
	}

	@Override
	/* This method is run by the UI thread when doInBackground is finished */
	protected void onPostExecute(Boolean result) {
		Log.i(TAG, "onPostExecute() - thread is done");
		activity.setProgressBarIndeterminateVisibility(false);// show progress
																// bar

	}

	@Override
	protected void onCancelled() {
		Log.i(TAG, "onCancelled() - cancel thread");
		activity.setProgressBarIndeterminateVisibility(false);// show progress
																// bar
	}

	/* used to make formatted time string */
	private String getTime(Calendar cal) {
		int hour = cal.get(Calendar.HOUR_OF_DAY);
		int minute = cal.get(Calendar.MINUTE);
		int second = cal.get(Calendar.SECOND);

		String sHour = String.valueOf(hour);
		String sMinute = String.valueOf(minute);
		String sSecond = String.valueOf(second);

		if (sHour.length() == 1)
			sHour = "0" + sHour;
		if (sMinute.length() == 1)
			sMinute = "0" + sMinute;
		if (sSecond.length() == 1)
			sSecond = "0" + sSecond;
		return sHour + ":" + sMinute + ":" + sSecond;
	}
}
