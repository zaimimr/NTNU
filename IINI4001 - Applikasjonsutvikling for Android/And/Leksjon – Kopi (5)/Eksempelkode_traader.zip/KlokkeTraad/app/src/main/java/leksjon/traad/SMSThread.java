package leksjon.traad;

public class SMSThread extends Thread{
	   private TimeActivityWithThreads activity;

	   public SMSThread(TimeActivityWithThreads activity){
		   this.activity = activity;
	   }
	   
	   @Override
	   public void run() {
			while (!isInterrupted()){ //run until interrupted
				sendSMS();
			}
	   }
	      
	   private void sendSMS(){
			activity.setSmsView("Sending new sms");
			
			sleep(10);//sleep 10 seconds, pretend sending sms
			
			activity.setSmsView("Done sending sms");
			sleep(5);//sleep a bit
	   }
	   
	   private void sleep(int seconds){
			try{
				Thread.sleep(seconds*1000);
			}catch(InterruptedException e){
				Thread.currentThread().interrupt();//set interrupt flag on thread (must do this)!
			}
		}	   
}
