package oving8.internasjonalisering;



import java.text.DateFormat;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;

import android.app.Activity;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView tvCurrencyValue;
    private TextView tvDateValue;
    private TextView tvCountryValue;
    private TextView tvLanguageValue;
    private ImageView flag;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        Locale locale = getResources().getConfiguration().locale;
        
        //If norwegian (no,nb,nn) handle them as one. 
        //CHANGE DEFAULT LOCALE -> remeber to add android:configChanges="locale" in AndroidManifest.xml
        if (locale.getLanguage().equals("no") || locale.getLanguage().equals("nb") || locale.getLanguage().equals("nn")){
         	locale = new Locale("no","NO");
        	Configuration config = new Configuration();
        	config.locale = locale;
        	Resources res = getBaseContext().getResources();
        	res.updateConfiguration(config, res.getDisplayMetrics());
        }
        
        setContentView(R.layout.main);//set default locale before setting view content
        
        tvDateValue = (TextView)findViewById(R.id.tvDateValue);
        tvCurrencyValue = (TextView)findViewById(R.id.tvCurrencyValue);
        tvCountryValue = (TextView)findViewById(R.id.tvCountryValue);
        tvLanguageValue = (TextView)findViewById(R.id.tvLanguageValue);
        
        flag			= (ImageView)findViewById(R.id.flag);
        
        //If known country show flag, otherwise hide it.
        if ( ! (locale.getCountry().equals("GB") || locale.getCountry().equals("US") || locale.getCountry().equals("NO"))){
        	flag.setVisibility(View.INVISIBLE);
        }
            
        String strCurrency = "";
        try{
        	Currency cur = Currency.getInstance(locale);//this will fail if not country specified!
            strCurrency = cur.getSymbol();
          }catch(Exception e){ 
        	Log.i("TAG","No country selected");
        }
        
        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.ENGLISH);
        String strDate = df.format(new Date());
                
        tvDateValue.setText(strDate);
        tvCurrencyValue.setText(strCurrency);
        tvCountryValue.setText(locale.getCountry());
        tvLanguageValue.setText(locale.getLanguage());   
    }
}