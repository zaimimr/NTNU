/* T.H 19/10-2012 */

package no.hist.aitel.android.leksjon.lagringstilbyder;

import android.app.Activity;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

public class ContentTestActivity extends Activity {
	public final static String TAG = "TEST_ACTIVITY";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Log.i(TAG,"Starting ....");
      
        Uri uri = FileBookContentProvider.CONTENT_URI;//gets all books - use uri below to get only one book
        
        //Uri uri = ContentUris.withAppendedId(FileBookContentProvider.CONTENT_URI, 1);
        //=> content://no.hist.aitel.android.leksjon.lagringstilbyder.FileBookContentProvider/books/1
                
        Cursor fileCursor = getContentResolver().query(uri, null, null, null, null);//for new versions of android use CursorLoader.loadInBackground();
   
        int column = 1;//doesn't matter with this implementation
        String bookWithAuthors = fileCursor.getString(column);
        Log.i(TAG,bookWithAuthors);//write book/authors to log
        
        //methods as isAfterLast, isBeforeFirst() and many other are not implemented!!!! only moveToNext()
        fileCursor.moveToNext();
        bookWithAuthors = fileCursor.getString(column);
        Log.i(TAG,bookWithAuthors);//write book/authors to log
    }
}