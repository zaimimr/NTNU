/* T.H 19/10-2012 */

package no.hist.aitel.android.leksjon.lagringstilbyder;

import java.util.ArrayList;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import no.hist.itfag.oving5.FileHandler;


public class FileBookContentProvider extends ContentProvider {
	public static final String TAG="FileBookContentProvider";
    public static final String PROVIDER_NAME = 
        "no.hist.aitel.android.leksjon.lagringstilbyder.FileBookContentProvider";
    
     public static final Uri CONTENT_URI = 
        Uri.parse("content://"+ PROVIDER_NAME + "/books");

     private static final int BOOKS = 1;
     private static final int BOOK_ID = 2;   

     private static final UriMatcher uriMatcher;
     static{ //request string (uri) tells us what (cursor to return) - used in the getType() and query() method 
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(PROVIDER_NAME, "books", BOOKS);
        uriMatcher.addURI(PROVIDER_NAME, "books/#", BOOK_ID);      
     }
   
    @Override
    public String getType(Uri uri){
       Log.i(TAG,"getType " + uri);
       switch (uriMatcher.match(uri)){
          //---get all books---
          case BOOKS:
             return "vnd.android.cursor.dir/vnd.books "; //this is explanation of what's returned
          //---get a particular book---
          case BOOK_ID:                
             return "vnd.android.cursor.item/vnd.books ";//this is explanation of what's returned
          default:
             throw new IllegalArgumentException("Unsupported URI: " + uri);        
       }   
    }
    
    @Override
    public boolean onCreate() {
       Log.i(TAG,"onCreate()");
       return true;
    }
    
    /* Returns a book or books with its authors. Projection,selection,selectionArgs and sortOrder are not "implemented". */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection,String[] selectionArgs, String sortOrder) {
       Log.i(TAG,"query() start.... mot URI=" + uri.getPath());
       FileCursor cursor = null;
       ArrayList<Book> books = new ArrayList<Book>();//keep books
       books = loadAllBooksFromFile();
       
       if (books.size() <= 0) return null;
              
       int requestType = uriMatcher.match(uri);
       if (requestType == BOOK_ID){ //BOOK_ID ---if getting a particular book---
    	   int i = Integer.parseInt(uri.getLastPathSegment());//get book number
    	   cursor =  new FileCursor(books.subList(i-1, i));//only one book in cursor
       }else if (requestType == BOOKS){
    	   cursor =  new FileCursor(books);//all books in cursor
       }
       return cursor;       
    }
    
    //loads all the books on file!    
    private ArrayList<Book> loadAllBooksFromFile(){
       ArrayList<Book> books = new ArrayList<Book>();//keep books
       FileHandler fh = new FileHandler(getContext(),R.raw.books);
       String fromFile = fh.readAll();
       Log.i(TAG,"FromFile=" + fromFile);
       String[] allFileArray = fromFile.split("\n");
    
       ArrayList<String> authors = new ArrayList<String>();
       
       int id = 0;
       for (String s : allFileArray){
    	   if (s.contains("Author")){
    		   int indexOfAuthorName = s.indexOf(": ") + 2; 
    		   authors.add(s.substring(indexOfAuthorName));
    	   }else{
    		   int indexOfBookName = s.indexOf(": ") + 2;
    		   String bookName = s.substring(indexOfBookName);
    		   Book b = new Book(++id,bookName,authors);
    		   books.add(b);
    		   authors.clear();//next iteration will get a new book and new authors
    	   }
       }
       return books;
    }
    
    /* NOT implemented => not possible to add, update or delete content */
	@Override
	public Uri insert(Uri uri, ContentValues values) {
	    return null;
	}
	  
	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
	   return 0;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}
    
}