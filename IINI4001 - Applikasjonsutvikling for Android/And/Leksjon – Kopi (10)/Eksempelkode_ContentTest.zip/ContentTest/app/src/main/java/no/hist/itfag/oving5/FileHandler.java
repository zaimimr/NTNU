package no.hist.itfag.oving5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.content.Context;

public class FileHandler {
	private InputStreamReader isr=null;
	static final int READ_BLOCK_SIZE = 100;

	public FileHandler(Context context, int id) {
	   		InputStream is = context.getResources().openRawResource(id);
	   		isr = new InputStreamReader(is);
	}
	public String readAll() {
		StringBuffer res = new StringBuffer();
		char[] inputBuffer = new char[READ_BLOCK_SIZE];
		int charRead;
		try {
			while ((charRead=isr.read(inputBuffer))>0) {
				String readString = String.copyValueOf(inputBuffer,0,charRead);
				res.append(readString);
				inputBuffer = new char[READ_BLOCK_SIZE];
			}
			isr.close();
		}	
		catch (IOException e) {
    		e.printStackTrace();
		}	
		return res.toString();
	}
}