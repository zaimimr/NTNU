/* T.H 19/10-2012 */
/* This is a very simple and incomplete example of a cursor implementation.
 * There are a lot of methods inherited from CursorWrapper which should/could be
 * implemented in this class.
 */

package no.hist.aitel.android.leksjon.lagringstilbyder;

import java.util.List;
import android.database.CursorWrapper;

public class FileCursor extends CursorWrapper{
	public final static String TAG="FileCursor";
	private List<Book> books;
	private int position=0;//which books are wanted
	
	
	
	public FileCursor(List<Book> books_Authors){
		super(null);
		this.books = books_Authors;
	}
		
	public String[] getColumnNames(){
		String[] s = {"Book","Authors"}; 
		return s;
	}
	
	public int getPosition(){
		return position;
	}
	
	public String getString(int columnIndex){
		return books.get(position).toString();
	}
	
	/* This method must be implemented to get example working */
	@Override
	public int getCount(){
		return books.size();
	}
	
	/* This method must be implemented to get example working */
	@Override
	public boolean moveToNext(){
		boolean isOk = false;
		if (position < books.size()-1){
			position++;
			isOk = true;
		}
		return isOk;
	}
}
