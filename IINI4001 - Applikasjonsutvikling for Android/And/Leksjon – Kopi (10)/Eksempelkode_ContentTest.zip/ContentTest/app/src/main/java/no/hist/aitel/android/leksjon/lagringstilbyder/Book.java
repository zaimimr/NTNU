/* T.H 19/10-2012 */

package no.hist.aitel.android.leksjon.lagringstilbyder;

import java.util.ArrayList;

public class Book {
	private int id;
	private String name;
	private ArrayList<String> authors;
	
	public Book(int id, String name, ArrayList<String> authors){
		this.name = name;
		this.authors = authors;
	}
	
	public int getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
	
	public String getAuthors(){
		String tmp = "";
		for (String s : authors){
			tmp += s;
		}
		return tmp;
	}
	
	public String toString(){
		String ret = name + "\n";
		for (String s : authors){
			ret += s + "\n";
		}
		return ret;
	}
}
